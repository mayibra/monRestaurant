const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const app = express();
const PORT = process.env.PORT || 3001;
const db = mongoose.connection;


/* GET home page. */
router.get('/', (req, res, next) => {
      //TODO
      mongoose.model('Restaurants').find({}, (err, items) => {
            if (err)
              return res.send(err);
        
            res.render('index', { title: 'Mon Restaurant', restaurants: items });
  });
});

router.get('/create', function (req, res, next) {
      res.render('create');
 });

 router.get('/delete/:id', function (req, res, next) {
  mongoose.model('Restaurant').findByIdAndRemove(req.params.id, function (err, item) {
    if (!err)
      return res.redirect('/');

    res.send(err);
  });
});


 // Démarrage de l'API server
app.listen(PORT, function() {
      console.log(`API Server now listening on PORT ${PORT}!`);
    });
    
    // Connection à Mongo DB
    mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost/noYelp");
    //Vérification
    db.on('error', console.error.bind(console, 'MongoDB connection error:'));
    
    
    
    

module.exports = router;
